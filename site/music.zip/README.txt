Music Effects is not available in this offline build.

The vendor implements it as a separate Windows helper program
(the music.zip download on the vendor site), which this Linux build
does not include. Lighting, key mapping, macros, performance/RT and
all other settings work normally and fully offline.
